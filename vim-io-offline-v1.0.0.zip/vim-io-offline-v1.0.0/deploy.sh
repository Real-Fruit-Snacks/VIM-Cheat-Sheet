#!/bin/bash

echo "🚀 VIM.io Offline Deployment Script"
echo "=================================="

# Check if gitlab-public exists
if [ ! -d "gitlab-public" ]; then
    echo "❌ Error: gitlab-public directory not found!"
    exit 1
fi

echo "✅ Pre-built files found in gitlab-public/"
echo ""

echo "📋 Deployment Options:"
echo ""
echo "1. GitLab Pages Deployment:"
echo "   - Push this folder to your GitLab repository"
echo "   - GitLab CI will automatically deploy from gitlab-public/"
echo ""
echo "2. Static Web Server:"
echo "   - Serve the gitlab-public/ directory with any web server"
echo "   - Ensure proper CORS headers (see _headers file)"
echo ""
echo "3. Verification:"
echo "   - Run: cd gitlab-public && sha256sum -c ../checksums.txt"
echo "   - This verifies file integrity"
echo ""

# Quick integrity check
if command -v sha256sum >/dev/null 2>&1; then
    echo "🔒 Running integrity check..."
    cd gitlab-public
    if sha256sum -c ../checksums.txt >/dev/null 2>&1; then
        echo "✅ All files verified successfully!"
    else
        echo "⚠️  Warning: Some files may have been modified"
    fi
    cd ..
fi

echo ""
echo "📚 See GITLAB_DEPLOYMENT.md for detailed instructions"
echo "🔧 See TROUBLESHOOTING.md if you encounter issues"
echo "🔒 See SECURITY.md for security considerations"
